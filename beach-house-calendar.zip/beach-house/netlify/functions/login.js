// netlify/functions/login.js
// This just re-exports the auth handler — the path tells it which mode to use
const { handler } = require("./auth");
exports.handler = handler;
