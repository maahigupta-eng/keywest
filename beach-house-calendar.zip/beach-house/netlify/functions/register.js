// netlify/functions/register.js
const { handler } = require("./auth");
exports.handler = handler;
