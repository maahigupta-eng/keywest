# Casa Kallman · Key West Beach House Calendar

A private family calendar for managing stays at the Key West house.

---

## Setup

### 1. Push to GitHub
Create a new GitHub repo and push this entire folder to it.

### 2. Connect to Netlify
1. Go to [netlify.com](https://netlify.com) → **Add new site → Import from GitHub**
2. Select your repo
3. Build settings will auto-detect from `netlify.toml`
4. Click **Deploy**

### 3. Set Environment Variables
In Netlify: **Site Settings → Environment Variables**, add these:

| Variable | Value | Notes |
|---|---|---|
| `GUEST_PASSKEY` | `sunsetkeys2025` | Change this. Shared with guests. |
| `FAMILY_PASSKEY` | `kallman2025` | Change this. Used to register family accounts. |
| `JWT_SECRET` | *(random long string)* | Generate with: `openssl rand -base64 32` |

> **Note:** The `GUEST_PASSKEY` and `FAMILY_PASSKEY` can be the same or different. If different, guests get one code to view open dates, and family get a separate code to create accounts.

### 4. Enable Netlify Blobs
Netlify Blobs is auto-enabled on all sites with Netlify Functions. No extra setup needed.

### 5. Redeploy
After setting env vars, trigger a new deploy in Netlify dashboard.

---

## How It Works

**Landing page:** Anyone who visits sees a passkey prompt. No content is shown without entering a code.

**Guest mode:** Enter the guest passkey → view the calendar showing only dates marked "Open for guests." Cannot add or edit anything.

**Family mode:** Click "I'm a family member" → enter name + password. First person to register becomes admin. Register using the family passkey.

**Admin:** Can delete any booking. Can mark bookings as "family only" (hidden from guests) or "open for guests" (visible to anyone with the passkey).

---

## Moving to a Custom Domain
1. In Netlify: **Domain Management → Add custom domain**
2. Follow DNS instructions (add CNAME or A record at your domain registrar)
3. Netlify handles HTTPS automatically
4. The app code doesn't change at all — it's fully domain-agnostic

---

## Phase 2 (coming soon)
- Mii-style avatar builder for each family member
- Avatar chips displayed on calendar days
- "Who's at the house" visual panel
